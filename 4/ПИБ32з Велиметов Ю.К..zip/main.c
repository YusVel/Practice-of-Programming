#include <stdio.h>
#include <stdlib.h>
#include "foo.c"



int main()
{
zadacha1();
zadacha2();
zadacha3();
zadacha4();	
}
