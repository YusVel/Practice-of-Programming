#include <stdio.h>
#include <stdlib.h>
#include "foo.c"



int main()
{
zadacha4();	
}
